package collect.bsr;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;




@Entity
public class customer {
	
	@Id
	private int cid;
	private String cname;
	@ManyToOne
	@JoinColumn(name="bid")
	private Bike bike;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Bike getBike() {
		return bike;
	}
	public void setBike(Bike bike) {
		this.bike = bike;
	}
	@Override
	public String toString() {
		return "customer [cid=" + cid + ", cname=" + cname + ", bike=" + bike + "]";
	}
	public customer(int cid, String cname, Bike bike) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.bike = bike;
	}
	
	public customer() {
	}
	

}
