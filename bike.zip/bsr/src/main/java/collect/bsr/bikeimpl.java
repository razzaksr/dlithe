package collect.bsr;

	import java.util.List;
	import java.util.Scanner;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;
	import org.hibernate.query.Query;

	public class  bikeimpl {
		
		SessionFactory factory=null;
		Session session=null;
		
		
	public void create()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    
	    Bike b1=new Bike(1,"herohonda",500000);
	    Bike b2=new Bike(2, "yamaha", 600000);
	    
	    session.save(b1);
	    session.save(b2);
		session.getTransaction().commit();
		session.close();
	   
	}

	public void update()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    
		Bike t=(Bike)session.get(Bike.class,2);
		
	    t.setBname("pulser");// update
	    session.update(t);

		session.getTransaction().commit();
		session.close();
	}
	public void delete()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		Bike s3=(Bike)session.get(Bike.class, 1);// read
	    session.delete(s3);
	    session.getTransaction().commit();
		session.close();
	}
	public void list()
	{

		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		 Query qry=session.createQuery("select bname from Bike");
	     List<Bike> pool=qry.list();
	     System.out.println(pool);
	     session.getTransaction().commit();
	 	session.close();
	 }


	public void read()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		Bike temp=(Bike)session.get(Bike.class, 1);// read
	    System.out.println(temp);
		session.getTransaction().commit();
	 	session.close();
	}
	}

