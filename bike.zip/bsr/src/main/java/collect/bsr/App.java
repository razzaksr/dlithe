package collect.bsr;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       bikeimpl b=new bikeimpl();
        //b.create();
        //b.read();
        //b.update();
        //b.delete();
        //b.list();
        
        customerimpl c=new customerimpl();
        c.create();
       // c.read();
        //c.update();
        //c.delete();
       // c.list();
        
    }
}
