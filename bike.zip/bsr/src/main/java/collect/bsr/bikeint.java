package collect.bsr;

public interface bikeint {

	public void create();
	public void read();
	public void update();
	public void delete();
	public void list();
}
