package collect.bsr;

	import java.util.List;
	
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;
	import org.hibernate.query.Query;



	public class customerimpl {
		
		SessionFactory factory=null;
		Session session=null;
		
		
	public void create()
	{
		Bike d1 = new Bike(1, "kAWASAKI", 20000);
		Bike d2 = new Bike(2, "KTM",50000);
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    
	   customer c1=new customer(1,"mani",d1);
	   customer c2=new customer(2, "ram",d2);
	   customer c3=new customer(3, "abh",d2);
	   customer c4=new customer(4, "manu",d2);
	   customer c5=new customer(5, "akash",d1);
	    session.save(c1);
	    session.save(c2);
	    session.save(c3);
	    session.save(c4);
	    session.save(c5);
		session.getTransaction().commit();
		session.close();
	   
	}

	public void update()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
	    
	    customer t=(customer)session.get(customer.class,2);
		
	    t.setCname("ramesh");// update
	    session.update(t);

		session.getTransaction().commit();
		session.close();
	}
	public void delete()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		customer s3=(customer)session.get(customer.class, 1);// read
	    session.delete(s3);
	    session.getTransaction().commit();
		session.close();
	}
	public void list()
	{

		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		 Query qry=session.createQuery("select cname from customer");
	     List<customer> pool=qry.list();
	     System.out.println(pool);
	     session.getTransaction().commit();
	 	session.close();
	 }


	public void read()
	{
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
	    Session session=factory.openSession();
	    session.beginTransaction();
		customer temp=(customer)session.get(customer.class, 1);// read
	    System.out.println(temp);
		session.getTransaction().commit();
	 	session.close();
	}
	}




