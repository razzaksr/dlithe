public class ParticipateNotFoundException extends Exception {
	
	public ParticipateNotFoundException(String message)
	{
		super(message);
	}
}
