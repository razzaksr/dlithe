import org.junit.Assert;
import org.junit.Test;
public class TestAll {
	@Test
	public void testskill()
	{
		Details d=new Details();
		d.getSkills().add("Java");
		d.getSkills().add("Python");
		Assert.assertTrue(d.getSkills().contains("Python"));
	}
	@Test
	public void testcgpa()
	{
		Details d1=new Details();
		Details d2=new Details();
		Details d3=new Details();
		Details d4=new Details();
		d1.setName("Ani");
		d1.setCGPA(5.0);Warehouse.D1.add(d1);
		d2.setName("Pawan");
		d2.setCGPA(9.5);Warehouse.D1.add(d2);
		d3.setName("Geetha");
		d3.setCGPA(9.2);Warehouse.D1.add(d3);
		d4.setName("Swathi");
		d4.setCGPA(9.3);Warehouse.D1.add(d4);
		for(Details d:Warehouse.D1)
		{
			Assert.assertTrue(d.getCGPA()>=8.9);
		}
	}
	@Test
	public void testsize()
	{
		Details d=new Details();
		Assert.assertEquals(0,Warehouse.D1.size() );
	}
	@Test
	public void testremove()
	{
	Details d=new Details();
	d.setName("Abhi");
	Assert.assertFalse(Warehouse.D1.contains(d));
	Warehouse.D1.remove(d);
	}
	@Test
	public void testupdate()
	{
		Details d=new Details();
		d.setName("Abhi");
		Assert.assertFalse(Warehouse.D1.contains(d));
		Warehouse.D1.remove(d);
		d.getSkills().add("DS");
	}
}
