import java.util.ArrayList;
import java.util.List;

public class Warehouse {
static List<Details> D1=new ArrayList<>();
public void list()
{
	System.out.println(D1);
}
}
