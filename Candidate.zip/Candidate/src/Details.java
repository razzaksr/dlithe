import java.util.ArrayList;
import java.util.List;

public class Details {
private String name;
private double CGPA;
private List<String> Skills= new ArrayList<>();
private String email;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getCGPA() {
	return CGPA;
}
public void setCGPA(double cGPA) {
	CGPA = cGPA;
}
public List<String> getSkills() {
	return Skills;
}
public void setSkills(List<String> skills) {
	Skills = skills;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "name=" + name + ", CGPA=" + CGPA + ", Skills=" + Skills + ", email=" + email;
}
public Details(String name, float cGPA, List<String> skills, String email) {
	super();
	this.name = name;
	CGPA = cGPA;
	Skills = skills;
	this.email = email;
}
public Details() {
	// TODO Auto-generated constructor stub
}
}
