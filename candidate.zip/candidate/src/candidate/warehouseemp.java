package candidate;
import org.junit.*;
public class warehouseemp {
	
	@Test
	public void testsize()
	{
		warehouse c=new warehouse();
		Assert.assertEquals(0,warehouse.list.size());
		
	}

}
