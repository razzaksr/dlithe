package candidate;

//port junit.framework.Assert;
import org.junit.*;
import org.junit.jupiter.api.Test;

public class testSkill {
	
	@Test
	public void t()
	{
		candidate1 c=new candidate1();
		c.getskills().add("java");
		c.getskills().add("python");
		Assert.assertTrue(c.getskills().contains("python"));
	}


}
