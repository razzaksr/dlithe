package candidate;

import java.util.*;
public class candidate1 {

	
		// TODO Auto-generated method stub
		private String name;
		private double cgpa;
		//private String skills;
		private List<String> skills=new ArrayList<String>();
		private String email;
		
		public String getname() {
	        return this.name;
	    }
	 
	    public void setname(String name) {
	       this.name = name;
	    }
	    
	    public double getcgpa() {
	        return this.cgpa;
	    }
	 
	    public void setcgpa(double cgpa) {
	       this.cgpa = cgpa;
	    }
	    
	    public List<String> getskills() {
	        return this.skills;
	    }
	 
	    public void setskills(List<String> skills) {
	       this.skills = skills;
	    }
	    
	    public String getemail() {
	        return this.email;
	    }
	 
	    public void setemail(String email) {
	       this.email = email;
	    }
	    
	    public candidate1() {};
	    public candidate1(String name,double cgpa,List<String> skills,String email)
	    {
	    	this.name=name;
	    	this.cgpa=cgpa;
	    	this.skills=skills;
	    	this.email=email;
	    	
	    }
	    
	    public String toString()
	      {
	    	  return name+" "+cgpa+" "+skills+" "+email+"\n";
	      }
}
	    
	    /*public static void main(String args[])
	    {
	    	Scanner sc=new Scanner(System.in);
	    	candidate1 c=new candidate1();
	    	System.out.println("enter the candidate name");
	    	String name1=sc.nextLine();
	    	System.out.println("enter the candidate cgpa");
	    	int cgpa1=sc.nextInt();
	    	System.out.println("enter the candidate skills");
	    	String skills1=sc.nextLine();
	    	System.out.println("enter the candidate email");
	    	String email1=sc.nextLine();
	    	c.setname(name1);
	    	c.setcgpa(cgpa1);
	    	c.setskills(skills1);
	    	c.setemail(email1);
	    	
	    	System.out.println(c);
	    	
	    }

	}*/


