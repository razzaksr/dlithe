package candidate;
import org.junit.*;
public class testcgpa {
	
	@Test
	public void test1()
	{
		candidate1 c=new candidate1();
		candidate1 c1=new candidate1();
		candidate1 c2=new candidate1();
		candidate1 c3=new candidate1();
		c.setname("swathi");
		c.setcgpa(8.39);warehouse.list.add(c);
		c1.setname("ram");
		c1.setcgpa(8.00);warehouse.list.add(c1);
		c2.setname("raj");
		c2.setcgpa(8.09);warehouse.list.add(c2);
		c3.setname("sham");
		c3.setcgpa(7.00);warehouse.list.add(c3);
		for(candidate1 d:warehouse.list)
		{
			Assert.assertTrue(d.getcgpa()>=8.9);
		}
		
	}

}
