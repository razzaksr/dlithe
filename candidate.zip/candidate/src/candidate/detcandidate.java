package candidate;
import org.junit.*;
public class detcandidate {
	
	@Test
	public void det()
	{
		candidate1 c=new candidate1();
		c.setname("ramm");
		Assert.assertFalse(warehouse.list.contains(c));
		warehouse.list.remove(c);
		
	}

}
