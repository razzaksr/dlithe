package candidate;
import java.util.*;
public class warehouse
{
	
	static ArrayList<candidate1> list=new ArrayList<candidate1>();
	{
	System.out.println("candidate1");
}
}