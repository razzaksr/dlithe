/**
 * 
 */
/**
 * @author HP
 *
 */
module candidate {
}