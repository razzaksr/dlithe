public class ParticipantNotFoundException extends Exception
	{
		public ParticipantNotFoundException(String e)
		{	
				super(e);
		}
}