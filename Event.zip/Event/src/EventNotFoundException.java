public class EventNotFoundException extends Exception{
	public EventNotFoundException(String e)
	{
		super(e);
	}
}